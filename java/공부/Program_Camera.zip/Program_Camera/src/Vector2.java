public class Vector2 {
    public Vector2(){
        this.x = 0;
        this.y = 0;
    }
    public Vector2(float x, float y){
        this.x = x;
        this.y = y;
    }
    public float x;
    public float y;
}
