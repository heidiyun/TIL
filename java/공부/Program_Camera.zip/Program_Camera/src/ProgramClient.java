public class ProgramClient {
    public static void main(String[] args) {

        Window.main("Window");

    }


}


