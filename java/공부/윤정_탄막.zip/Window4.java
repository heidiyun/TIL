import processing.core.PApplet;

import java.util.ArrayList;
import java.util.List;

public class Window4 extends PApplet {

    public static void main(String[] args) {
        PApplet.main("Window4");
    }

    public void settings() {
        size(960, 640);
    }

    List<ExampleEllipse> ellipses;

    public void setup() { // 원충돌 어떻게 할까?
        ellipses = new ArrayList<>();
    }

    boolean col = false;
    int x = 480, y = 320;
    int r = 100;
    int tick = 0;

    public void draw() {
        background(0);
        tick++;

        fill(150, 100, 255);
        rect(x, y, 50, 50);

        if (keyPressed) {
            if (key == CODED) {
                    if (keyCode == LEFT) {
                        System.out.println("왼쪽");
                        x -= 10;
                    } else if (keyCode == RIGHT) {
                        System.out.println("오른쪽");
                        x += 10;
                    } else if (keyCode == UP) {
                        System.out.println("위쪽");
                        y -= 10;
                    } else if (keyCode == DOWN) {
                        System.out.println("아래쪽");
                        y += 10;
                    }
                }
        }
        if (tick % 30== 0) {
           // if (mousePressed) {
                ExampleEllipse e = new ExampleEllipse(this, x, y);
                ellipses.add(e);
            //}
        }

        for (int i = 0; i < ellipses.size(); i++) {
            fill(100, 255, 240);
            ellipses.get(i).update();
            ellipses.get(i).render();

            if (Math.sqrt(Math.pow((x + 25) - (ellipses.get(i).x), 2) +
                    Math.pow((y + 25) - (ellipses.get(i).y), 2)) <= 30) {
                col = true;
            }

            if (col == true) {
                background(0);
                return;
            }
        }


//            if (ellipses.get(i).x > 0 || ellipses.get(i).x < 960
//                ||ellipses.get(i).y > 0 || ellipses.get(i).y < 640 )  {
//
//                ellipses.get(i).update();
//                ellipses.get(i).render();


    }


}



