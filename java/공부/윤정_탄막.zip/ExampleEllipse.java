import processing.core.PApplet;

public class ExampleEllipse extends ExampleBaseObject {

    private int radius;

    public ExampleEllipse (PApplet p, float x, float y) {
        super(p);
        this.x = -100;
        this.y = 100;
        this.vx = x / 100;
        this.vy = y / 100;
        radius = 20;
    }

    @Override
    public void update() {

        x += vx ;
        y += vy ;
    }

    public void update2() {
        vy = -5;
        ay += (float) - 0.5;
        vy -= ay;
        y  -= vy;
        ax += (float) Math.random() * 0.2f - 0.1f;
        vx += ax;
        x  += vx;

    }


    @Override
    public void render() {
        pApplet.ellipse(x, y, radius, radius);
    }
}
